import os
import json

# 文件路径
json_file_path = r"D:\data\Tennis Player Actions Dataset for Human Pose Estimation\annotations\backhand.json"
image_dir_path = r"D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\backhand"
output_dir_path = r"D:\data\Tennis Player Actions Dataset for Human Pose Estimation\yolo_format"

# 创建输出目录
os.makedirs(output_dir_path, exist_ok=True)

# 加载 JSON 文件
with open(json_file_path) as f:
    data = json.load(f)

annotations = data['annotations']
images_info = {img['id']: img for img in data['images']}
categories_info = {cat['id']: cat['name'] for cat in data['categories']}
category_id_to_class_id = {cat_id: index for index, cat_id in enumerate(categories_info.keys())}


def convert_bbox_coco_to_yolo(size, box):
    dw = 1. / size[0]
    dh = 1. / size[1]
    x = box[0] + box[2] / 2.0
    y = box[1] + box[3] / 2.0
    w = box[2]
    h = box[3]
    x *= dw
    w *= dw
    y *= dh
    h *= dh
    return (x, y, w, h)


# 遍历注释
for annotation in annotations:
    image_id = annotation['image_id']
    category_id = annotation['category_id']
    image_info = images_info[image_id]
    file_name = image_info['file_name']
    image_width = image_info['width']
    image_height = image_info['height']
    bbox = annotation['bbox']

    # 计算 YOLO 格式的边界框
    yolo_bbox = convert_bbox_coco_to_yolo((image_width, image_height), bbox)

    # 获取类 ID
    class_id = category_id_to_class_id[category_id]

    # 创建一个对应的 txt 文件（与图像文件同名）
    txt_file_path = os.path.join(output_dir_path, f"{os.path.splitext(file_name)[0]}.txt")

    with open(txt_file_path, 'a') as txt_file:
        # 写入 YOLO 格式的数据
        txt_file.write(f"{class_id} " + " ".join(map(str, yolo_bbox)) + '\n')

print("YOLO 格式转换完成！")
