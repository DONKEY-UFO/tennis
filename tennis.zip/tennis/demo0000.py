def run(model_name, video_path):
    logs = []
    logs_list = []
    model = YOlO(model_name)
    results = model(video_path, save=True)  # saved

    for r in results:
        r_xy = r.boxes.xyxy.tolist()
        logs.append(r_xy[0] if r_xy!=[] else [])
    print(logs)

    for xy in logs:
        if xy == []:
            logs_list.append([])
        else:
            logs_list.append([int(xy[0]), int(xy[1])])

    return logs_list