import matplotlib.pyplot as plt
import networkx as nx

# 创建一个有向图
G = nx.DiGraph()

# 添加节点和边
G.add_edge("扁平化治理下农村公共体育服务供需适配的纾解路径", "强化部门横向联动")
G.add_edge("扁平化治理下农村公共体育服务供需适配的纾解路径", "提高资源整合效率")
G.add_edge("扁平化治理下农村公共体育服务供需适配的纾解路径", "搭建农村数字交流平台")
G.add_edge("扁平化治理下农村公共体育服务供需适配的纾解路径", "降低多元主体监督门槛")

G.add_edge("强化部门横向联动", "政府顶层设计")
G.add_edge("强化部门横向联动", "明确任务分解与责权分配")
G.add_edge("强化部门横向联动", "鼓励市场与社会力量参与")

G.add_edge("提高资源整合效率", "健全监督机制")
G.add_edge("提高资源整合效率", "确保财政投入优化")
G.add_edge("提高资源整合效率", "精准定位多元需求")

G.add_edge("搭建农村数字交流平台", "设立综合性信息平台")
G.add_edge("搭建农村数字交流平台", "运行线上服务中心")

G.add_edge("降低多元主体监督门槛", "拓宽监管幅度")
G.add_edge("降低多元主体监督门槛", "降低外部主体监督准入门槛")

# 绘制图形
plt.figure(figsize=(12, 8))
pos = nx.spring_layout(G)  # 选择一种布局
nx.draw(G, pos, with_labels=True, node_size=3000, node_color="skyblue", font_size=10, font_weight="bold", arrowsize=15)
plt.title("农村公共体育服务治理框架图")
plt.show()