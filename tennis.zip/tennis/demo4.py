from ultralytics import YOLO

# Load a model
model = YOLO("yolov8n-pose.pt")  # load a custom model

# Predict with the model
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_001.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_002.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_003.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_004.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_005.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_006.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_007.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_008.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_009.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_010.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_011.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_012.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_013.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_014.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_015.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_016.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_017.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_018.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_019.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_020.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_021.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_022.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_023.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_024.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_025.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_026.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_027.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_028.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_029.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_030.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_031.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_032.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_033.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_034.jpeg",save_txt=True)  # predict on an image
results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_035.jpeg",save_txt=True)  # predict on an image