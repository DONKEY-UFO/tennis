import os
from ultralytics import YOLO

# Initialize the YOLO model
model = YOLO("yolov8n-pose.pt")


def process_images(directory_path, model, save_txt=True):
    template = "F_{:03}.jpeg"  # Format for filenames like S_001.jpeg
    output_results = []

    for i in range(1, 451):
        filename = template.format(i)
        file_path = os.path.join(directory_path, filename)

        if os.path.exists(file_path):
            results = model(file_path, save_txt=save_txt)
            output_results.append(results)  # Store result for each image
        else:
            print(f"File {file_path} does not exist.")

    return output_results


# Define the directory containing your images
directory = "D:\\data\\Tennis Player Actions Dataset for Human Pose Estimation\\images\\forehand\\"

# Process images and get results
results = process_images(directory, model, save_txt=True)