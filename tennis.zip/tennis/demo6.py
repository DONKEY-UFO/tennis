import numpy as np

# 定义每个类别的真实样本总数
total_samples = {
    'backhand': 100,
    'forehand': 100,
    'serve': 100,
    'background': 100
}

# 标准化混淆矩阵
normalized_cm = np.array([
    [0.85, 0.12, 0.04, 0.56],  # backhand
    [0.13, 0.86, 0.00, 0.37],  # forehand
    [0.00, 0.02, 0.96, 0.00],  # serve
    [0.02, 0.00, 0.06, 0.00]    # background
])

# 计算未标准化的混淆矩阵
cm = normalized_cm * np.array([
    total_samples['backhand'],
    total_samples['forehand'],
    total_samples['serve'],
    total_samples['background']
]).reshape(-1, 1)

# 提取TP、FP、FN
TP = np.diag(cm)
FP = cm.sum(axis=0) - TP
FN = cm.sum(axis=1) - TP

# 计算精确率、召回率和F1分数
precision = TP / (TP + FP)
recall = TP / (TP + FN)
f1_score = 2 * (precision * recall) / (precision + recall)

# 计算准确率
accuracy = np.sum(TP) / np.sum(cm)

# 输出结果
labels = ['backhand', 'forehand', 'serve', 'background']
for i, label in enumerate(labels):
    print(f"{label} - Precision: {precision[i]:.2f}, Recall: {recall[i]:.2f}, F1 Score: {f1_score[i]:.2f}")

print(f"\nOverall Accuracy: {accuracy:.2f}")