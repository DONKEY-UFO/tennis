from ultralytics import YOLO


def run(model_name, video_path):
    logs = []
    logs_list = []
    # try:
    model = YOLO(model_name)
    results = model(video_path, save=True)  # saved

    # View results
    for r in results:
        r_xy = r.boxes.xyxy.tolist()
        # print(r_xy)
        # logs.append(r_xy[0]) if r_xy!=[] else None
        logs.append(r_xy[0] if r_xy!=[] else [])
        # logs.append(r_xy[0])
    print(logs)

    for xy in logs:
        if xy == []:
            logs_list.append([])
        else:
            logs_list.append([int(xy[0]), int(xy[1])])

    # for i in range(0, len(logs)):
    #     xys = []
    #     xys.append([int(logs[i][0]), int(logs[i][1])])
    #     logs_list.append(xys)
    return logs_list


if __name__ == '__main__':
    # 加载模型
    model_name = 'runs/detect/train7/weights/best.pt'
    # 视频路径
    video_path = 'D:\测试2.mp4'
    logs = run(model_name, video_path)
    print(logs)