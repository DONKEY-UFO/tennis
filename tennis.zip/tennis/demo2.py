from ultralytics import YOLO

# 加载模型或构建新模型并加载预训练权重
model = YOLO("yolov8n-pose.pt")

# 训练模型
results = model.train(data="D:\demo1\demo1.yaml", epochs=200, imgsz=640,workers=0)
