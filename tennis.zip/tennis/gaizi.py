import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 定义混淆矩阵数据
cm_data = np.array([[131, 9, 4, 9],    # backhand
                    [13, 133, 6, 0],   # forehand
                    [0, 8, 138, 0],   # serve
                    [6, 0, 2, 0]])  # background

# 定义类别标签
labels = ['backhand', 'forehand', 'serve', 'background']

# 绘制混淆矩阵
plt.figure(figsize=(10, 8))
sns.heatmap(cm_data, annot=True, fmt='d', cmap='Blues',
            xticklabels=labels, yticklabels=labels)
plt.title('Confusion Matrix')
plt.xlabel('True')
plt.ylabel('Predicted')
plt.show()