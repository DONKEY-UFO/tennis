from ultralytics import YOLO

# Load a model
model = YOLO("yolov8n-pose.pt")  # load a custom model

# Predict with the model

results = model("D:\data\Tennis Player Actions Dataset for Human Pose Estimation\images\serve\S_394.jpeg",save=True,show_labels=False,save_txt=True)  # predict on an image
